![iu](https://github.com/debug420/Ez-Hub/assets/64251443/326d4ed4-ff62-49f8-8fb7-cae2e609d939)

```lua
loadstring(game:HttpGet(('https://raw.githubusercontent.com/debug42O/Ez-Industries-Launcher-Data/master/Launcher.lua'),true))()
```

--------------------------------------------
<br/>

```diff
- NOTE: EZ HUB IS NO LONGER IN ACTIVE DEVELOPMENT. HIGH RISK OF GETTING BANNED ON CERTAIN GAMES.
```
<br/>
Welcome to the repository of Ez Hub. Ez Hub is an open source script hub with exclusive scripts. It does not log any information regarding the client. Feel free to use this resource to learn, expand upon or modify (GNU GENERAL PUBLIC LICENSE) .<br/>
<br/>
Changelog and Docs: https://app.archbee.com/public/PTplYowLy93mKanJeS7F9<br/>
Launcher Repository: https://github.com/debug420/Ez-Industries-Launcher-Data<br/>
If you wish to contact me, you can do so on Discord: cottient<br/>
<br/>
Showcases of Ez Hub by other users:<br/>
<br/>
http://www.youtube.com/watch?v=uKDxKKKSr1c<br/>
http://www.youtube.com/watch?v=l9PhPh3yjYo<br/>
http://www.youtube.com/watch?v=9-DpdBgDwVc<br/>
